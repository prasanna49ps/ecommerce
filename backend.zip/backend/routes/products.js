// for to take over node express
const express = require('express');
const { getProducts, getSingleProduct } = require('../controllers/productcontrollers');
const router = express.Router();
// setting a routing path
router.route('/products').get(getProducts);
router.route('/products/:id').get(getSingleProduct);


module.exports = router;
